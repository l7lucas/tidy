function Home() {
  return <h2>Bem-vindo à Tidy!</h2>;
}

export default Home;

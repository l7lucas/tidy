function Veiculos() {
  return <h2>Página de Veículos</h2>;
}
export default Veiculos;

function Financas() {
  return <h2>Página de Finanças</h2>;
}
export default Financas;

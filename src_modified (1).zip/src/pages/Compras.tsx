function Compras() {
  return <h2>Página de Compras</h2>;
}
export default Compras;
